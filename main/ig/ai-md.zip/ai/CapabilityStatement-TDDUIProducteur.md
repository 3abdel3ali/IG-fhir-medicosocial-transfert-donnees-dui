# TDDUI-Producteur - Médicosocial - Transfert de données DUI v2.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **TDDUI-Producteur**

Médicosocial - Transfert de données DUI - Local Development build (v2.0.0) built by the FHIR (HL7® FHIR® Standard) Build Tools. See the [Directory of published versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html)

*  [Narrative Content](#) 
*  [XML](CapabilityStatement-TDDUIProducteur.xml.md) 
*  [JSON](CapabilityStatement-TDDUIProducteur.json.md) 
*  [TTL](CapabilityStatement-TDDUIProducteur.ttl.md) 

## CapabilityStatement: TDDUI-Producteur 

| | |
| :--- | :--- |
| *Official URL*:https://interop.esante.gouv.fr/ig/fhir/tddui/CapabilityStatement/TDDUIProducteur | *Version*:2.0.0 |
| Active as of 2024-06-20 | *Computable Name*:TDDUIProducteur |

 
Le rôle de Producteur est de transmettre des données de son logiciel DUI. Il correspond à un logiciel DUI. 

 [Raw OpenAPI-Swagger Definition file](TDDUIProducteur.openapi.json) | [Download](TDDUIProducteur.openapi.json) 

## TDDUI-Producteur

* Version du guide dimplémentation : {0} 
* Version de FHIR : 4.0.1 
* Supported Formats: `application/fhir+xml`, `application/fhir+json`
* Publié sur : 2024-06-20 15:51:35+0200 
* Publié par : ANS 

> **Note aux implémenteurs : capacités FHIR**Any FHIR capability may be 'allowed' by the system unless explicitly marked as 'SHALL NOT'. A few items are marked as MAY in the Implementation Guide to highlight their potential relevance to the use case.

### DOIT prendre en charge les guides d’implémentation suivants.

* https://interop.esante.gouv.fr/ig/fhir/tddui

## FHIR RESTful Capabilities

### Mode: client

Transmission de données DUI vers un SI tiers (flux 1).

**Security**

> 

L’ANS propose des référentiels dédiés à la politique de sécurité (la PGSSI-S) et des mécanismes de sécurisation sont définis dans les volets de la couche Transport du Cadre d’Interopérabilité des systèmes d’information de santé (CI-SIS)


**Summary of System-wide Interactions**

* Supports the `transaction`Les interactions sont décrites comme suit :

https://interop.esante.gouv.fr/ig/fhir/tddui/StructureDefinition/tddui-bundle


### Capabilities by Resource/Profile

#### Résumé

Le tableau récapitulatif liste les ressources faisant partie de cette configuration, et pour chaque ressource, il liste :

* The relevant profiles (if any)
* Les interactions supportées par chaque ressource (**R**ead, **S**earch, **U**pdate, and **C**reate, are always shown, while **VR**ead, **P**atch, **D**elete, **H**istory on **I**nstance, or **H**istory on **T**les types sont seulement présents si au moins une des ressources les prend en charge.
* Les paramètres de recherche (SearchParameters) requis, recommandés, optionnels (le cas échéant).
* The linked resources enabled for `_include`
* The other resources enabled for `_revinclude`
* The operations on the resource (if any)

| | | | | | | | | | |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| [Patient](#Patient1-1) | Supported Profiles  [TDDUI Patient](StructureDefinition-tddui-patient.md)  [TDDUI Patient INS](StructureDefinition-tddui-patient-ins.md) |  |  |  | y |  |  |  |  |
| [Organization](#Organization1-2) | Supported Profiles  [TDDUI Organization](StructureDefinition-tddui-organization.md) |  |  |  | y |  |  |  |  |
| [Encounter](#Encounter1-3) | Supported Profiles  [TDDUI Encounter Sejour](StructureDefinition-tddui-encounter-sejour.md) |  |  |  | y |  |  |  |  |

-------

#### Resource Conformance: supported Patient

Ressource FHIR coeur

[Patient](http://hl7.org/fhir/R4/patient.html)

Reference Policy

Résumé des interactions

* Supports `create`.

Supported Profiles
[TDDUI Patient](StructureDefinition-tddui-patient.md)
[TDDUI Patient INS](StructureDefinition-tddui-patient-ins.md)

#### Resource Conformance: supported Organization

Ressource FHIR coeur

[Organization](http://hl7.org/fhir/R4/organization.html)

Reference Policy

Résumé des interactions

* Supports `create`.

Supported Profiles
[TDDUI Organization](StructureDefinition-tddui-organization.md)

#### Resource Conformance: supported Encounter

Ressource FHIR coeur

[Encounter](http://hl7.org/fhir/R4/encounter.html)

Reference Policy

Résumé des interactions

* Supports `create`.

Supported Profiles
[TDDUI Encounter Sejour](StructureDefinition-tddui-encounter-sejour.md)

| | | |
| :--- | :--- | :--- |
|  [<prev](CapabilityStatement-TDDUIConsommateur.ttl.md) | [top](#top) |  [next>](CapabilityStatement-TDDUIProducteur-testing.md) |

 IG © 2023+ [ANS](https://esante.gouv.fr). Package ans.fhir.fr.tddui#2.0.0 based on [FHIR 4.0.1](http://hl7.org/fhir/R4/). Generated 2025-10-02 
  Liens : [Table des matières](toc.md) | [QA](qa.md) | [Historique des versions](https://interop.esante.gouv.fr/ig/fhir/tddui/history.html) [Documentation](https://interop.esante.gouv.fr/ig/documentation) | [New Issue](https://github.com/ansforge/IG-fhir-medicosocial-transfert-donnees-dui/issues/new)  

